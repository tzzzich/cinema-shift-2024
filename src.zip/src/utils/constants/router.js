export const ROUTES = {
    ROOT: '/',
    FILMDETAIL: '/film/:id'
  };
  